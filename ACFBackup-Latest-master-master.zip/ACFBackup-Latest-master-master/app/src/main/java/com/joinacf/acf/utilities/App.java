package com.joinacf.acf.utilities;


import android.app.Application;

import com.joinacf.acf.sms_verification.AppSignatureHelper;

/**
 * Created on : May 21, 201Secure@1239
 * Author     : AndroidWave
 */
public class App extends Application {
  @Override
  public void onCreate() {
    super.onCreate();
    AppSignatureHelper appSignatureHelper = new AppSignatureHelper(this);
    appSignatureHelper.getAppSignatures();
  }
}
